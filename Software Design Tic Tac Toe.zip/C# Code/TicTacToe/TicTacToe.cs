﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class TI : Form
    {
        bool turn = true; //When True = X Turn; False = Y Turn
        int turn_count = 0;

     

        public TI()
        {
            InitializeComponent();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("In this game the first player to place either 3 O's or 3 X's in a row vertically, horizontally or diagonnally wins.\n\nX always goes first, O always goes second.\n\nUse a friendly game of Rock Paper Scissors or flip a coin to decide between yourselves who goes first.","Instructions: How to Play");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit(); // quits application
        }

        private void button_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender; 
            if(turn)
            { b.Text = "X"; // makes button turn to X
              current_icon.Text = "Current Player: O"; //sets bottom label to current player's icon
              current_icon.Font = new Font("MS Sans Serif", 14, FontStyle.Regular, GraphicsUnit.Point);
              current_icon.Refresh(); //Refresh() is used to ensure that there are no issues with the text updating.
            } 
            else
            { b.Text = "O"; // makes button turn to O
              current_icon.Text = "Current Player: X "; //sets bottom label to current player's icon
              current_icon.Font = new Font("MS Sans Serif", 14, FontStyle.Regular, GraphicsUnit.Point);
              current_icon.Refresh(); //Refresh() is used to ensure that there are no issues with the text updating.
            } 

            turn = !turn; // Changes the button to X and O
            b.Enabled = false; // Stops a button from being changed from what it already was
            turn_count++;
            checkForWinner();
        }


        private void checkForWinner()
        {
            bool there_is_a_winner = false;

            // all of the horizontal checks
            if ((RAC1.Text == RAC2.Text) && (RAC2.Text == RAC3.Text) && (!RAC1.Enabled))
                there_is_a_winner = true;
           else if ((RBC1.Text == RBC2.Text) && (RBC2.Text == RBC3.Text) && (!RBC1.Enabled))
                there_is_a_winner = true;
            else if ((RCC1.Text == RCC2.Text) && (RCC2.Text == RCC3.Text) && (!RCC1.Enabled))
                there_is_a_winner = true;

            // all of the vertical checks
            else if ((RAC1.Text == RBC1.Text) && (RBC1.Text == RCC1.Text) && (!RAC1.Enabled))
                there_is_a_winner = true;
            else if ((RAC2.Text == RBC2.Text) && (RBC2.Text == RCC2.Text) && (!RAC2.Enabled))
                there_is_a_winner = true;
            else if ((RAC3.Text == RBC3.Text) && (RBC3.Text == RCC3.Text) && (!RAC3.Enabled))
                there_is_a_winner = true;

            // diagonal checks
            else if ((RAC1.Text == RBC2.Text) && (RBC2.Text == RCC3.Text) && (!RAC1.Enabled))
                there_is_a_winner = true;
            else if ((RCC1.Text == RBC2.Text) && (RBC2.Text == RAC3.Text) && (!RCC1.Enabled))
                there_is_a_winner = true;
           

            // messge box thats lets players know who won
            if (there_is_a_winner)
            {
                disableButtons();//stop buttons from working when there is a winner

                String winner = "";
                if (turn)
                    winner = "O";
                else
                    winner = "X";
                MessageBox.Show(winner + " is the winner!", "Congrats!");
            }
            else
            {
                if (turn_count == 9)
                    MessageBox.Show("Draw!", "Try Again!");
            }
                

        }// To see if there is a winner

        //Stops the buttons from working
        private void disableButtons()
        {
            foreach(Control c in Controls)
            {
                try
                {
                    Button w = (Button)c;
                    w.Enabled = false;
                }
                catch { }// the try catch is so that this void runs because without it it detects the meesage bar as the box.
              
            }
        }

        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            turn = true;
            turn_count = 0;
            //Resets the label text so that it is back to the original state.
            current_icon.Text = "Current Player: X ";
            current_icon.Font = new Font("MS Sans Serif", 14, FontStyle.Regular, GraphicsUnit.Point);
            current_icon.Refresh(); //Refresh() is used to ensure that there are no issues with the text updating.

            foreach (Control c in Controls)
            {
                try
                {
                    Button w = (Button)c;
                    w.Enabled = true;
                    w.Text = "";
                }
                catch { }// the try catch is so that this void runs because without it it detects the meesage bar as the box.

            }

        }

    }
}
