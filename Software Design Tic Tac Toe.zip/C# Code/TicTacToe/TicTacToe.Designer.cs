﻿namespace WindowsFormsApp1
{
    partial class TI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RAC1 = new System.Windows.Forms.Button();
            this.RCC3 = new System.Windows.Forms.Button();
            this.RBC3 = new System.Windows.Forms.Button();
            this.RCC2 = new System.Windows.Forms.Button();
            this.RBC2 = new System.Windows.Forms.Button();
            this.RAC2 = new System.Windows.Forms.Button();
            this.RCC1 = new System.Windows.Forms.Button();
            this.RBC1 = new System.Windows.Forms.Button();
            this.RAC3 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.current_icon = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // RAC1
            // 
            this.RAC1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RAC1.Location = new System.Drawing.Point(9, 34);
            this.RAC1.Margin = new System.Windows.Forms.Padding(2);
            this.RAC1.Name = "RAC1";
            this.RAC1.Size = new System.Drawing.Size(64, 69);
            this.RAC1.TabIndex = 0;
            this.RAC1.UseVisualStyleBackColor = true;
            this.RAC1.Click += new System.EventHandler(this.button_Click);
            // 
            // RCC3
            // 
            this.RCC3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RCC3.Location = new System.Drawing.Point(165, 197);
            this.RCC3.Margin = new System.Windows.Forms.Padding(2);
            this.RCC3.Name = "RCC3";
            this.RCC3.Size = new System.Drawing.Size(64, 69);
            this.RCC3.TabIndex = 1;
            this.RCC3.UseVisualStyleBackColor = true;
            this.RCC3.Click += new System.EventHandler(this.button_Click);
            // 
            // RBC3
            // 
            this.RBC3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RBC3.Location = new System.Drawing.Point(165, 115);
            this.RBC3.Margin = new System.Windows.Forms.Padding(2);
            this.RBC3.Name = "RBC3";
            this.RBC3.Size = new System.Drawing.Size(64, 69);
            this.RBC3.TabIndex = 2;
            this.RBC3.UseVisualStyleBackColor = true;
            this.RBC3.Click += new System.EventHandler(this.button_Click);
            // 
            // RCC2
            // 
            this.RCC2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RCC2.Location = new System.Drawing.Point(88, 197);
            this.RCC2.Margin = new System.Windows.Forms.Padding(2);
            this.RCC2.Name = "RCC2";
            this.RCC2.Size = new System.Drawing.Size(64, 69);
            this.RCC2.TabIndex = 3;
            this.RCC2.UseVisualStyleBackColor = true;
            this.RCC2.Click += new System.EventHandler(this.button_Click);
            // 
            // RBC2
            // 
            this.RBC2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RBC2.Location = new System.Drawing.Point(88, 115);
            this.RBC2.Margin = new System.Windows.Forms.Padding(2);
            this.RBC2.Name = "RBC2";
            this.RBC2.Size = new System.Drawing.Size(64, 69);
            this.RBC2.TabIndex = 4;
            this.RBC2.UseVisualStyleBackColor = true;
            this.RBC2.Click += new System.EventHandler(this.button_Click);
            // 
            // RAC2
            // 
            this.RAC2.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RAC2.Location = new System.Drawing.Point(88, 34);
            this.RAC2.Margin = new System.Windows.Forms.Padding(2);
            this.RAC2.Name = "RAC2";
            this.RAC2.Size = new System.Drawing.Size(64, 69);
            this.RAC2.TabIndex = 5;
            this.RAC2.UseVisualStyleBackColor = true;
            this.RAC2.Click += new System.EventHandler(this.button_Click);
            // 
            // RCC1
            // 
            this.RCC1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RCC1.Location = new System.Drawing.Point(9, 197);
            this.RCC1.Margin = new System.Windows.Forms.Padding(2);
            this.RCC1.Name = "RCC1";
            this.RCC1.Size = new System.Drawing.Size(64, 69);
            this.RCC1.TabIndex = 6;
            this.RCC1.UseVisualStyleBackColor = true;
            this.RCC1.Click += new System.EventHandler(this.button_Click);
            // 
            // RBC1
            // 
            this.RBC1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RBC1.Location = new System.Drawing.Point(9, 115);
            this.RBC1.Margin = new System.Windows.Forms.Padding(2);
            this.RBC1.Name = "RBC1";
            this.RBC1.Size = new System.Drawing.Size(64, 69);
            this.RBC1.TabIndex = 7;
            this.RBC1.UseVisualStyleBackColor = true;
            this.RBC1.Click += new System.EventHandler(this.button_Click);
            // 
            // RAC3
            // 
            this.RAC3.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RAC3.Location = new System.Drawing.Point(165, 34);
            this.RAC3.Margin = new System.Windows.Forms.Padding(2);
            this.RAC3.Name = "RAC3";
            this.RAC3.Size = new System.Drawing.Size(64, 69);
            this.RAC3.TabIndex = 8;
            this.RAC3.UseVisualStyleBackColor = true;
            this.RAC3.Click += new System.EventHandler(this.button_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(4, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(238, 24);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newGameToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // newGameToolStripMenuItem
            // 
            this.newGameToolStripMenuItem.Name = "newGameToolStripMenuItem";
            this.newGameToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.newGameToolStripMenuItem.Text = "New Game";
            this.newGameToolStripMenuItem.Click += new System.EventHandler(this.newGameToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.aboutToolStripMenuItem.Text = "Instructions";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // current_icon
            // 
            this.current_icon.AutoSize = true;
            this.current_icon.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.current_icon.Location = new System.Drawing.Point(42, 282);
            this.current_icon.Name = "current_icon";
            this.current_icon.Size = new System.Drawing.Size(153, 24);
            this.current_icon.TabIndex = 10;
            this.current_icon.Text = "Current Player: X";
            // 
            // TI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(238, 315);
            this.Controls.Add(this.current_icon);
            this.Controls.Add(this.RAC3);
            this.Controls.Add(this.RBC1);
            this.Controls.Add(this.RCC1);
            this.Controls.Add(this.RAC2);
            this.Controls.Add(this.RBC2);
            this.Controls.Add(this.RCC2);
            this.Controls.Add(this.RBC3);
            this.Controls.Add(this.RCC3);
            this.Controls.Add(this.RAC1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximumSize = new System.Drawing.Size(254, 354);
            this.MinimumSize = new System.Drawing.Size(254, 354);
            this.Name = "TI";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tic Tac Toe";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button RAC1;
        private System.Windows.Forms.Button RCC3;
        private System.Windows.Forms.Button RBC3;
        private System.Windows.Forms.Button RCC2;
        private System.Windows.Forms.Button RBC2;
        private System.Windows.Forms.Button RAC2;
        private System.Windows.Forms.Button RCC1;
        private System.Windows.Forms.Button RBC1;
        private System.Windows.Forms.Button RAC3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newGameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Label current_icon;
    }
}

