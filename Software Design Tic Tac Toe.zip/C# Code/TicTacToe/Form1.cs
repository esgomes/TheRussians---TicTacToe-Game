﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class TI : Form
    {
        bool turn = true; //When True = X Turn; False = Y Turn
        int turn_count = 0;
        public TI()
        {
            InitializeComponent();
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("In this game the first player to place either 3 O's or 3 X's in a row vertically, horizontally or diagonnally wins.\n\nX always goes first, O always goes second.\n\nUse a friendly game of Rock Paper Scissors or flip a coin to decide between yourselves who goes first.","Instructions: How to Play");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit(); // quits application
        }

        private void button_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender; 
            if(turn)
            { b.Text = "X";} // makes button turn to X
            else
            { b.Text = "O"; } // makes button turn to O

            turn = !turn; // Changes the button to X and O
            b.Enabled = false; // Stops a button from being changed from what it already was
            turn_count++;
            checkForWinner();
        }

        private void checkForWinner()
        {
            bool there_is_a_winner = false;

            // all of the horizontal checks
            if ((A1.Text == A2.Text) && (A2.Text == A3.Text) && (!A1.Enabled))
                there_is_a_winner = true;
           else if ((B1.Text == B2.Text) && (B2.Text == B3.Text) && (!B1.Enabled))
                there_is_a_winner = true;
            else if ((C1.Text == C2.Text) && (C2.Text == C3.Text) && (!C1.Enabled))
                there_is_a_winner = true;

            // all of the vertical checks
            else if ((A1.Text == B1.Text) && (B1.Text == C1.Text) && (!A1.Enabled))
                there_is_a_winner = true;
            else if ((A2.Text == B2.Text) && (B2.Text == C2.Text) && (!A2.Enabled))
                there_is_a_winner = true;
            else if ((A3.Text == B3.Text) && (B3.Text == C3.Text) && (!A3.Enabled))
                there_is_a_winner = true;

            // diagnol checks
            else if ((A1.Text == B2.Text) && (B2.Text == C3.Text) && (!A1.Enabled))
                there_is_a_winner = true;
            else if ((C1.Text == B2.Text) && (B2.Text == A3.Text) && (!C1.Enabled))
                there_is_a_winner = true;
           

            // messge box thats lets players know who won
            if (there_is_a_winner)
            {
                disableButtons();//stop buttons from working when there is a winner

                String winner = "";
                if (turn)
                    winner = "O";
                else
                    winner = "X";
                MessageBox.Show(winner + " is the winner!", "Congrats!");
            }
            else
            {
                if (turn_count == 9)
                    MessageBox.Show("Draw!", "Try Again!");
            }
                

        }// To see if there is a winner

        //Stops the buttons from working
        private void disableButtons()
        {
            foreach(Control c in Controls)
            {
                try
                {
                    Button w = (Button)c;
                    w.Enabled = false;
                }
                catch { }// the try catch is so that this void runs because without it it detects the meesage bar as the box.
              
            }
        }

        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            turn = true;
            turn_count = 0;

            foreach (Control c in Controls)
            {
                try
                {
                    Button w = (Button)c;
                    w.Enabled = true;
                    w.Text = "";
                }
                catch { }// the try catch is so that this void runs because without it it detects the meesage bar as the box.

            }

        }

    }
}
